Co-curricular Module Poster
by Kevin Setiawan Miharjo + Design Team
using Adobe Photoshop 2020.
