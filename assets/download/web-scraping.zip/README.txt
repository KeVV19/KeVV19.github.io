Web-Scraping Instagram Post 
created by Kevin Setiawan Miharjo
using Adobe Illustrator 2020.

Logo, Icon and vectors are downloaded and taken from:
-www.freepik.com
-www.flaticon.com